# apple-clone
Built in php.

>Watch the fast coding tutorial on YouTube - https://www.youtube.com/watch?v=_DiHh_mQbQw&t
