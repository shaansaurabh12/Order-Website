<footer style="text-align: center; padding: 10px 0; ">
    <hr>
    Copyright &copy; <?php echo date('Y'); ?> Apple Inc. all rights reserved.
</footer>